# easyshop
database created 
registration done
