<?php
session_start();

if (isset($_SESSION['userSession']) != "") {
	header("Location: success.php");
}
require_once 'dbconnect.php';

if (isset($_POST['btn-signup'])){
	$customerName = strip_tags($_POST['customerName']);

	$customerCountry = strip_tags($_POST['customerCountry']);
	$customerCity = strip_tags($_POST['customerCity']);
	$customerStreet = strip_tags($_POST['customerStreet']);
	$customerZip = strip_tags($_POST['customerZip']);

	$customerGender = strip_tags($_POST['customerGender']);
	$customerAge = strip_tags($_POST['customerAge']);
	$customerPhone = strip_tags($_POST['customerPhone']);
	$customerEmail = strip_tags($_POST['customerEmail']);
	$customerPass = strip_tags($_POST['customerPass']);




	$customerName = $DBcon->real_escape_string($customerName);

	$customerCountry = $DBcon->real_escape_string($customerCountry);
	$customerCity = $DBcon->real_escape_string($customerCity);
	$customerStreet = $DBcon->real_escape_string($customerStreet);
	$customerZip = $DBcon->real_escape_string($customerZip);
	
	$customerGender = $DBcon->real_escape_string($customerGender);
	$customerAge = $DBcon->real_escape_string($customerAge);
	$customerPhone = $DBcon->real_escape_string($customerPhone);
	$customerEmail = $DBcon->real_escape_string($customerEmail);
	$customerPass = $DBcon->real_escape_string($customerPass);

	//encrypt password
	$hashed_password = password_hash($customerPass, PASSWORD_DEFAULT);

	$check_email = $DBcon->query("SELECT c_email
		FROM customer
		WHERE c_email = '$customerEmail'");
	$check_address = $DBcon->query("SELECT a_id
		FROM address
		WHERE country = '$customerCountry' 
		AND city = '$customerCity' 
		AND street = '$customerStreet'
		AND zip = '$customerZip'");

	if ($check_email->num_rows != 0) {
		$msg = "<div>
		<h3>
		Sorry email already taken !
		</h3>
		</div>";
	}
	else if ($check_address->num_rows != 0) {
		$address_result = $check_address->fetch_array();
		$address_id = $address_result["a_id"];
		$DBcon->query("ALTER TABLE customer AUTO_INCREMENT=1");
		$query = "INSERT INTO customer(c_name, a_id, gender, age, phone, c_email, password)
		VALUES('$customerName', $address_id, '$customerGender',
		$customerAge, '$customerPhone', '$customerEmail', '$hashed_password')";
		if ($DBcon->query($query)) {
			$msg = "<div>
			<h3>
			Successfully registered !
			</h3>
			</div>";
		}
		else {
			$msg = "<div>
			<h3>
			Getting error !
			</h3>
			</div>";
		}
	}
	else {
		$query1 = "INSERT INTO address(country, city, street, zip)
		VALUES('$customerCountry', '$customerCity', '$customerStreet', '$customerZip')";
		$DBcon->query("ALTER TABLE address AUTO_INCREMENT=1");//adjust id
		$DBcon->query($query1);

		$address_id = $DBcon->query("SELECT a_id
			FROM address
			WHERE country = '$customerCountry' 
			AND city = '$customerCity' 
			AND street = '$customerStreet'
			AND zip = '$customerZip'");
		$address_result = $address_id->fetch_array();
		$add_id = $address_result["a_id"];
		$query2 = "INSERT INTO customer(c_name, a_id, gender, age, phone, c_email, password)
		VALUES('$customerName', $add_id, '$customerGender',
		$customerAge, '$customerPhone', '$customerEmail', '$hashed_password')";
		
		$DBcon->query("ALTER TABLE customer AUTO_INCREMENT=1");
		if ($DBcon->query($query2)) {
			$msg = "<div>
			<h3>
			Successfully registered !
			</h3>
			</div>";
		}
		else {
			$msg = "<div>
			<h3>
			Getting error !
			</h3>
			</div>";
		}
	}
	$DBcon->close();
}
?>
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Register</title>
	<!-- Bootstrap Styles-->
	<link href="assets/css/bootstrap.css" rel="stylesheet" />
	<!-- FontAwesome Styles-->
	<link href="assets/css/font-awesome.css" rel="stylesheet" />
	<!-- Morris Chart Styles-->
	<link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
	<!-- Custom Styles-->
	<link href="assets/css/custom-styles.css" rel="stylesheet" />
	<!-- Google Fonts-->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

	<style>
		hr.style-two {
			border: 0;
			height: 1px;
			background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));
		}
		hr.style-four {
			height: 12px;
			border: 0;
			box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);
		}

	</style>

</head>

<?php require('header.php'); ?>
<?php require('menu.php'); ?>

<center>
	<form method="post" id="register-form">
		<h2>Sign Up</h2>
		<hr size="5" />

		<?php
		if (isset($msg)){
			echo $msg;
		}
		?>
		
		<div class="w3-third">
			<label> Your Name</label>
			<input type="text" name="customerName" class="form-control" style = "width:80%" placeholder="First name + Last name" required />
			<label> Gender</label>
			<input type="text" name="customerGender" class="form-control" style = "width:80%" placeholder="Male/Female" required />
		</div>

		<div class="w3-third">
			<label> Your Age</label>
			<input type="number" name="customerAge" class="form-control" style = "width:80%" placeholder="ex:20" required />
			<label> Phone Number</label>
			<input type="text" name="customerPhone" class="form-control" style = "width:80%" placeholder="ex:+1 (123)456-9000" required />
		</div>

		<div class="w3-third">
			<label> Email</label>
			<input type="text" name="customerEmail" class="form-control" style = "width:80%" placeholder="ex:info@example.com" required />
			<label> Password</label>
			<input type="password" name="customerPass" class="form-control" style = "width:80%" placeholder="6~14 numbers + characters" required />
		</div>

		<hr/>
		<h3 class="form-group">Your Address</h3><br>
		<hr class ="style-four"/>
		<?php

		$countries = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");

		?>
		<div class="form-group">
			<label>Passport Country*</label>
			<select name="customerCountry" class="form-control" style = "width:80%" required>
				<option value selected ></option>
				<?php
				foreach($countries as $key => $value):
				echo '<option value="'.$value.'">'.$value.'</option>'; //close your tags!!
			endforeach;
			?>
		</select>

	</div>

	<div class="form-group">
		<label>City</label>
		<input type="text" name="customerCity" class="form-control" style = "width:80%" placeholder="ex: Pittsburgh" required />
	</div>

	<div class="form-group">
		<label>Street</label>
		<input type="text" name="customerStreet" class="form-control" style = "width:80%" placeholder="ex: Fifth Ave." required />
	</div>

	<div class="form-group">
		<label>Zipcode</label>
		<input type="number" name="customerZip" class="form-control" style = "width:80%" placeholder="ex:15213" required />
	</div>

	<hr size="5" />

	<div>
		<br>
		<button type="submit" class="btn btn-default" name="btn-signup">
			<span></span> Create Account
		</button>
		<br>
		<br>
		<a id="login" href="signin.php" class="btn btn-default">Already have an account? Click  here to log in</a>
	</div>
</form>
<script src="assets/js/jquery-1.10.2.js"></script>
<!-- Bootstrap Js -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- Metis Menu Js -->
<script src="assets/js/jquery.metisMenu.js"></script>
<!-- Custom Js -->
<script src="assets/js/custom-scripts.js"></script>
</center>

<?php require('footer.php'); ?>