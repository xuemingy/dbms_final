<?php
session_start();
require_once 'dbconnect.php';
//购物车
//if cart is empty, show error
if (isset($_SESSION['prodCart']) == "" ) {
	echo '<script>alert("Your cart is empty")</script>';
	echo '<script>window.location="yourcart.php"</script>';
}
//check if already log in
else if (isset($_SESSION['userSession']) != "") {
	header("Location: orderResult.php");
	exit;
}
?>

<?php require('header.php'); ?>
<?php require('menu.php'); ?>

<!-- if not log in -->
<center><h1>Sorry, you will have to log in first!</h1></center>
<center><h3><a href="signin.php">Click here to log in</a></h3></center>