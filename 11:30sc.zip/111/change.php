<?php
session_start();
require_once 'dbconnect.php';

#更新用户信息

if (isset($_POST['btn-change'])) {
	if (!empty($_POST['newPassword'])){
		$newPassword = strip_tags($_POST['newPassword']);
		$newPassword = $DBcon->real_escape_string($newPassword);
		$newPassword_hash = password_hash($newPassword, PASSWORD_DEFAULT);

		$DBcon->query("UPDATE customer SET password = '$newPassword_hash'
						WHERE c_id = ".$_SESSION['userSession']."");
	}
	if (!empty($_POST['newEmail'])){
		$newEmail = strip_tags($_POST['newEmail']);
		$newEmail = $DBcon->real_escape_string($newEmail);

		$DBcon->query("UPDATE customer SET c_email = '$newEmail'
						WHERE c_id = ".$_SESSION['userSession']."");
	}
	if (!empty($_POST['newPhone'])){
		$newPhone = strip_tags($_POST['newPhone']);
		$newPhone = $DBcon->real_escape_string($newPhone);

		$DBcon->query("UPDATE customer SET phone = '$newPhone'
						WHERE c_id = ".$_SESSION['userSession']."");
	}
	if (!empty($_POST['newCountry']) && !empty($_POST['newCity']) && !empty($_POST['newStreet']) && !empty($_POST['newZip'])){
		$newCountry = strip_tags($_POST['newCountry']);
		$newCity = strip_tags($_POST['newCity']);
		$newStreet = strip_tags($_POST['newStreet']);
		$newZip = strip_tags($_POST['newZip']);

		$newCountry = $DBcon->real_escape_string($newCountry);
		$newCity = $DBcon->real_escape_string($newCity);
		$newStreet = $DBcon->real_escape_string($newStreet);
		$newZip = $DBcon->real_escape_string($newZip);

		$check_address = $DBcon->query("SELECT a_id
									 	FROM address
									 	WHERE country = '$newCountry' 
									 		AND city = '$newCity' 
									 		AND street = '$newStreet'
									 		AND zip = '$newZip'");
		if ($check_address->num_rows != 0) {
			$address_result = $check_address->fetch_array();
			$address_id = $address_result["a_id"];
			$query = "UPDATE customer SET a_id = $address_id
						WHERE c_id = ".$_SESSION['userSession']."";
			$DBcon->query($query);
		}
		else {
			$query1 = "INSERT INTO address(country, city, street, zip)
					   VALUES('$newCountry', '$newCity', '$newStreet', '$newZip')";
			$DBcon->query("ALTER TABLE address AUTO_INCREMENT=1");//adjust id
			$DBcon->query($query1);
			$address_id = $DBcon->query("SELECT a_id
										  FROM address
										  WHERE country = '$newCountry' 
										 	AND city = '$newCity' 
										 	AND street = '$newStreet'
										 	AND zip = '$newZip'");
			$address_result = $address_id->fetch_array();
			$add_id = $address_result["a_id"];
			$query2 = "UPDATE customer SET a_id = $add_id
						WHERE c_id = ".$_SESSION['userSession']."";
			$DBcon->query($query2);
		}
		echo '<script>alert("Successly Change Information!")</script>';
		session_destroy();
		unset($_SESSION['userSession']);
		echo '<script>window.location="signin.php"</script>';
		$DBcon->close();
	}
	else if (!empty($_POST['newCountry']) || !empty($_POST['newCity']) || !empty($_POST['newStreet']) || !empty($_POST['newZip'])){
		$msg = "<div>
				<h3>
				Please fill in the full address !
				</h3>
				</div>";
	}
	else{
		echo '<script>alert("Successly Change Information!")</script>';
		session_destroy();
		unset($_SESSION['userSession']);
		echo '<script>window.location="signin.php"</script>';
		$DBcon->close();
	}
	
}
?>
<head>
	<meta charset="utf-8">
	<title>Change</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<!-- Bootstrap Styles-->
	<link href="assets/css/bootstrap.css" rel="stylesheet" />
	<!-- FontAwesome Styles-->
	<link href="assets/css/font-awesome.css" rel="stylesheet" />
	<!-- Morris Chart Styles-->
	<link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
	<!-- Custom Styles-->
	<link href="assets/css/custom-styles.css" rel="stylesheet" />
	<!-- Google Fonts-->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
	

<?php require('header.php'); ?>
<?php require('menu.php'); ?>

<center>
	<form method="post" id="change-form">
		<h2>Change Your Information</h2>
		<hr size="5" />

		<div>
			<label>New Password:</label>
			<input type="password" name="newPassword" class="form-control"style = "width:80%" placeholder="New Password">
		</div>

		<div>
			<label>New Email:</label>
			<input type="text" name="newEmail" class="form-control" style = "width:80%" placeholder="New Email">
		</div>

		<div>
			<label>New Phone Number:</label>
			<input type="text" name="newPhone" class="form-control" style = "width:80%" placeholder="New Phone Number">
		</div>

		<hr size="5" />

		<div>
			<label>New Address:</label>
			<input type="text" name="newCountry" class="form-control" style = "width:80%" placeholder="New Country">
			<input type="text" name="newCity" class="form-control" style = "width:80%" placeholder="New City">
			<input type="text" name="newStreet" class="form-control" style = "width:80%" placeholder="New Street">
			<input type="number" name="newZip" class="form-control"style = "width:80%" placeholder="New Zip">
		</div>

		<hr size="5" />

		<?php
		if (isset($msg)){
			echo $msg;
		}
		?>
		
		<div>
			<br>
			<button type="submit" class="btn btn-default" name="btn-change">
				<span></span> Change Information
			</button>
			<br>
			<br>
		</div>
	</form>
</center>

<?php require('footer.php'); ?>