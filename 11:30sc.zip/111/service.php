<?php
session_start();
require_once 'dbconnect.php';

if (isset($_POST['back_hotel'])){
	unset($_SESSION['room_type']);
	unset($_SESSION['hotel_id']);
	header("Location: hotel.php");
}
?>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Bootstrap Styles-->
	<link href="assets/css/bootstrap.css" rel="stylesheet" />
	<!-- FontAwesome Styles-->
	<link href="assets/css/font-awesome.css" rel="stylesheet" />
	<!-- Morris Chart Styles-->
	<link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
	<!-- Custom Styles-->
	<link href="assets/css/custom-styles.css" rel="stylesheet" />
	<!-- Google Fonts-->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<?php require('menu.php'); ?>
<?php require('header.php'); ?>

<body>
	<div id="wrapper">
		<nav class="navbar-default navbar-side" role="navigation">
			<div class="sidebar-collapse">
				<ul class="nav" id="main-menu">
					<li>
						<a  href="index.php"><i class="fa fa-home"></i> Homepage</a>
					</li>
					<li>
						<a href="room.php" class="w3-content">Room</a>
					</li>

					<li>
						<a href="service.php" class="w3-content">Service</a>
					</li>
				</ul>

			</div>

		</nav>
		<div id="page-wrapper" >
			<div id="page-inner">
				<div class="row">
					<div class="col-md-12">
						<h1 class="page-header">
							Enjoy Yourself!<small></small>
						</h1>
						<h2>Hotle: <?php
						echo $_SESSION['hotel_id'];
						?></h2>

						<form method="post" id="search-room">
							<input type="text" name="search-service" style="width: 80%" placeholder="Search the service you want" class="form-control" required>
							<input type="submit" class="btn btn-default" value="Search" name="search-service-btn">
						</form>

						<hr size="10" />

						<?php
	//show all service
						if (!isset($_POST['search-service-btn'])) {
							$queryAll = $DBcon->query("SELECT s_id, s_name, price
								FROM service
								WHERE h_id = {$_SESSION['hotel_id']}");
							if ($queryAll->num_rows > 0) {
								?>
								<table class="w3-table-all w3-card-4" style="width: 80%" border="1">
									<tr>
										<th>Service Name</th>
										<th>Price</th>
										<th>Action</th>
									</tr>
									<?php
									while ($all = $queryAll->fetch_array()) {
										?>
										<form method="post" action="shop.php?action=addService&serviceId=<?php echo $all['s_id']; ?>">
											<tr>
												<td><?php echo $all['s_name']; ?></td>
												<td><?php echo $all['price']; ?></td>
												<td>
													<input type="submit"  class="btn btn-default" name="add_service" value="Add to cart">
												</td>
											</tr>
										</form>
										<?php
									}
									?>
								</table>
								<?php
							}
							else {
								echo "No Service in This Hotel!";
							}
						}
						else {
							$searchService = strip_tags($_POST['search-service']);
							$searchService = $DBcon->real_escape_string($searchService);

							$searchQuery = $DBcon->query("SELECT s_id, s_name, price
								FROM service
								WHERE s_name = '$searchService'
								AND h_id = {$_SESSION['hotel_id']}");
		//no result
							if ($searchQuery->num_rows == 0){
								echo "<div>
								<h3>
								Don't have service $searchService in this hotel, please search again!
								</h3>
								</div>";
								?>
								<table class="w3-table-all w3-card-4" style="width: 80%" border="1">
									<tr>
										<th>Service Name</th>
										<th>Price</th>
										<th>Action</th>
									</tr>
									<?php
									while ($all = $queryAll->fetch_array()) {
										?>
										<form method="post" action="shop.php?action=addService&serviceId=<?php echo $all['s_id']; ?>">
											<tr>
												<td><?php echo $all['s_name']; ?></td>
												<td><?php echo $all['price']; ?></td>
												<td>
													<input type="submit" class="btn btn-default" name="add_service" value="Add to cart">
												</td>
											</tr>
										</form>
										<?php
									}
									?>
								</table>
								<?php	
							}
							else {
								$searchResult = $searchQuery->fetch_array(); ?>
								<table class="w3-table-all w3-card-4" style="width: 80%" border="1">
									<tr>
										<th>Service Name</th>
										<th>Price</th>
										<th>Action</th>
									</tr>
									<tr>
										<form method="post" action="shop.php?action=addService&serviceId=<?php echo $searchResult['s_id']; ?>">
											<td><?php echo $searchResult['s_name'];?></td>
											<td><?php echo $searchResult['price']; ?></td>
											<td>
												<input type="submit" class="btn btn-default" name="add_service" value="Add to cart">
											</td>
										</form>
									</tr>
								</table>

								<?php
							}
						}

						?>

						<form method="post" id="return">
							<button type="submit" class="btn btn-default" name="back_hotel" id="back_hotel">
								Return
							</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>

<?php require('footer.php'); ?>