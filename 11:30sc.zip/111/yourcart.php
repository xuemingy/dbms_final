<?php
session_start();
require_once 'dbconnect.php';

if (isset($_POST['btn_history'])) {
	header("Location: historyorder.php");
}
?>
    <!-- Edited by SC-->
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Shopping Cart</title>
	<!-- Bootstrap Styles-->
	<link href="assets/css/bootstrap.css" rel="stylesheet" />
	<!-- FontAwesome Styles-->
	<link href="assets/css/font-awesome.css" rel="stylesheet" />
	<!-- Morris Chart Styles-->
	<link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
	<!-- Custom Styles-->
	<link href="assets/css/custom-styles.css" rel="stylesheet" />
	<!-- Google Fonts-->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

	<style>
		hr.style-two {
			border: 0;
			height: 1px;
			background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));
		}
		hr.style-four {
			height: 12px;
			border: 0;
			box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);
		}

	</style>

</head>
<?php require('header.php'); ?>
<?php require('menu.php'); ?>

<center>
	<form method="post" id="history-form">
		<button type="submit" class="btn btn-default" name="btn_history" id="btn_history">
			Check history orders
		</button>
	</form>


	<h2>Your shopping cart</h2>

	<hr size="10">

	<h3>Products</h3>

	<div>
		<table class="w3-table-all w3-card-4" style="width: 80%" border="1">
			<tr>
				<th>Product Name</th>
				<th>Amount</th>
				<th>Price</th>
				<th>Store</th>
                <th>Salesperson</th>
				<th>Delete</th>
			</tr>

			<?php
			$total = 0;

			if (!empty($_SESSION['prodCart'])) {
				foreach ($_SESSION['prodCart'] as $keys => $values) {
					?>
					<tr>
						<td><?php echo $values["prod_name"]; ?></td>
						<td><?php echo $values["qty"]; ?></td>
						<td><?php echo $values["price"]; ?></td>
						<td><?php echo $values["store_name"]; ?></td>
                        <td><?php echo $values["sid"]; ?></td>
						<td><a id="delete" href="shop.php?action=delRoom&roomId=<?php echo $values['room_id'];?>&hotelId=<?php echo $values['hotel_id'];?>"><span>X</span></a></td>
					</tr>
					<?php
					$total = $total + ($values["price"] * $values["qty"]);
				}
			}
			?>
		</table>
	</div>

	<hr size="5">



	<div>
		<p><u>Sub total:</u> $ <?php echo number_format($total,2);?></p>
		<p><u>Tax:</u> $ <?php echo number_format($total*0.07,2);?></p>
		<h3>Total: $ <?php echo number_format($total*1.07,2);?></h3>
		<h2><a id="checkout" href="checkout.php">Click here to check out</a></h2>
	</div>
</center>

<?php require('footer.php'); ?>