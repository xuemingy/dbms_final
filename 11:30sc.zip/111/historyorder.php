<?php
session_start();
require_once 'dbconnect.php';

$ID = $_SESSION['userSession'];

$queryRoom = $DBcon->query("SELECT date, room.r_id, room.h_id, room.r_kind, price
							FROM order_form,order_room,room,price
							WHERE c_id = $ID
								AND order_form.o_id = order_room.o_id
								AND order_room.r_id = room.r_id
								AND order_room.h_id = room.h_id
								AND room.r_kind = price.r_kind");
$queryService = $DBcon->query("SELECT date, service.s_name, service.h_id, price
							   FROM order_form, order_service, service
							   WHERE c_id = $ID
							   		AND order_form.o_id = order_service.o_id
							   		AND order_service.s_id = service.s_id
							   		AND order_service.h_id = service.h_id");

if (isset($_POST['btn_backcart'])){
	header("Location: yourcart.php");
}
?>
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Register</title>
	<!-- Bootstrap Styles-->
	<link href="assets/css/bootstrap.css" rel="stylesheet" />
	<!-- FontAwesome Styles-->
	<link href="assets/css/font-awesome.css" rel="stylesheet" />
	<!-- Morris Chart Styles-->
	<link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
	<!-- Custom Styles-->
	<link href="assets/css/custom-styles.css" rel="stylesheet" />
	<!-- Google Fonts-->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

	<style>
		hr.style-two {
			border: 0;
			height: 1px;
			background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));
		}
		hr.style-four {
			height: 12px;
			border: 0;
			box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);
		}

	</style>

</head>
<?php require('header.php'); ?>
<?php require('menu.php'); ?>

<center>
	<h2>Your Shopping History</h2>

	<hr size="10">
	<h3>Room</h3>

	<div>
		<table class="w3-table-all w3-card-4" style="width: 80%" border="1">
			<tr>
				<th>Hotel ID</th>
				<th>Room Number</th>
				<th>Room Type</th>
				<th>Price</th>
				<th>Date</th>
			</tr>
			<?php
			if ($queryRoom->num_rows > 0){
				while ($row = $queryRoom->fetch_array()){
					?>
					<tr>
						<td><?php echo $row['h_id']; ?></td>
						<td><?php echo $row['r_id']; ?></td>
						<td><?php echo $row['r_kind']; ?></td>
						<td><?php echo $row['price']; ?></td>
						<td><?php echo $row['date']; ?></td>
					</tr>
					<?php
				}
			}
			?>
		</table>
	</div>


	<form method="post">
		<button type="submit" class="btn btn-default" name="btn_backcart" id="btn_backcart">
			Back to cart
		</button>
	</form>
</center>

<?php require('footer.php'); ?>