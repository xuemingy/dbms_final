<!-- Edited by SC-->
<?php
session_start();
require_once 'dbconnect.php';

if (isset($_POST['add_prod'])) {
	$query = $DBcon->query("SELECT prod_id, prod_name, price
							FROM products
							WHERE prod_id = {$_GET['prodID']}");
	$row = $query->fetch_array();
	if (!isset($_SESSION["prodCart"])){
		$item_array = array(
		'prod_id' => $_SESSION['prod_id'],
		'prod_name' => $row['prod_name'],
		'price' => $row['price'],
        'amount' => $row['amount'],
		);
		$_SESSION['prodCart'][0] = $item_array;
		echo '<script>alert("Successfully added room to cart")</script>';
		echo '<script>window.location="room.php"</script>';
	}
	/*
	else {
		//$item_array_hotel = array_column($_SESSION['roomCart'], "hotel_id");
		$item_array_room = array_column($_SESSION['roomCart'], "prod_id");

		/*if (in_array($_GET['roomId'], $item_array_room) && in_array($_SESSION['hotel_id'], $item_array_hotel)) {
			echo '<script>alert("Room already added to cart")</script>';
			echo '<script>window.location="room.php"</script>';

		}

			$count = count($_SESSION['roomCart']);
			$item_array = array(
			'hotel_id' => $_SESSION['hotel_id'],
			'room_id' => $row['r_id'],
			'room_type' => $row['r_kind'],
			'price' => $row['price']
			);
			$_SESSION['roomCart'][$count] = $item_array;
			echo '<script>alert("Successfully added room to cart")</script>';
			echo '<script>window.location="room.php"</script>';

	}*/
}

//if delete
if (isset($_GET['action'])) {
	if ($_GET['action'] == "delRoom") {
		foreach ($_SESSION["prodCart"] as $keys => $values){
			if ($values["room_id"] == $_GET["roomId"] && $values["hotel_id"] == $_GET["hotelId"]) {
				unset($_SESSION["prodCart"][$keys]);
				echo '<script>alert("Product has been removed")</script>';
				echo '<script>window.location="yourcart.php"</script>';
			}
		}
	}

}
?>