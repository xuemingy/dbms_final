<?php
date_default_timezone_set('America/New_York');
session_start();
require_once 'dbconnect.php';

//get c_id
$customerId = $_SESSION['userSession'];
$query = $DBcon->query("SELECT first_name, last_name, email, zipcode
						FROM customer, user
						WHERE cusomer.cutsomer_id = user.cutsomer_id
						AND cutsomer_id = $customerId");
$row = $query->fetch_array();
$customerFName = $row["first_name"];
$customerLName = $row["last_name"];
$customerZipcode = $row['zipcode'];
$customerEmail = $row['c_email'];
$orderDate = date("Y-m-d H:i");

$manage = 0;
$manageHotel = 0;
if (isset($_SESSION["prodCart"][0])){
	$manage = $_SESSION["prodCart"][0];
	//$manageHotel = $manage["hotel_id"];
}


$order_manager = $DBcon->query("SELECT e_id
								FROM employee
								WHERE job_title = 'receptionist'
									AND h_id = $manageHotel");
$order_manager = $order_manager->fetch_array();
$order_manager = $order_manager["e_id"];

//insert order_form
$DBcon->query("ALTER TABLE address AUTO_INCREMENT=1");
$DBcon->query("INSERT INTO order_form(date, e_id, c_id)
			   VALUES('$orderDate', $order_manager, $customerId)");

$searchOrder = $DBcon->query("SELECT o_id
							  FROM order_form
							  WHERE date = '$orderDate'
							  	AND c_id = $customerId");
$searchOrder = $searchOrder->fetch_array();
$orderId = $searchOrder['o_id'];
?>

<?php require('header.php'); ?>
<?php require('menu.php'); ?>

<?php
echo "<p>Order processed at {$orderDate}</p>";
echo "<p>Customer: {$customerFName} {$customerLName}</p>";
echo "<p>Email: {$customerEmail}</p>";
echo "<p>Zipcode: {$customerZipcode}</p>";
echo "<h1>Your order is as follows:</h1>";

$total = 0;
if (!empty($_SESSION["prodCart"])) {
	foreach($_SESSION["prodCart"] as $keys => $values) {

		echo "<center>";
		echo "<br>";
		echo '<p> Product: <b>'.$values["prod_name"].'</b></p>';
		echo '<p> Amount: <b>'.$values["amount"].'</b></p>';
		echo '<p> Price: <b>$'.$values["price"].'</b></p>';
        echo '<p> Store: <b>$'.$values["Store_name"].'</b></p>';
        echo '<p> Salesperson: <b>$'.$values["sid"].'</b></p>';
		echo '<br>';
		echo '</center>';
		echo '<hr size="3">';

		//11/30 需要修改
		$total = $total + ($values["price"] * $values["amount"]);
		$DBcon->query("INSERT INTO transaction(transdate, totalprice, sid, costumer_id, )
						VALUES('$orderDate', '$total', ".$values['sid'].", ".$values['customer_id'].", ".$values['amount'].")");
		$DBcon->query("UPDATE room SET state = 1
						WHERE h_id = ".$values['hotel_id']."
							AND r_id = ".$values['room_id']."");
	}
}

?>

<center>
	<div>
		<p><u>Sub title</u>: $ <?php echo number_format($total,2); ?></p>
		<p><u>Tax</u>: $ <?php echo number_format($total*0.07); ?></p>
		<h3><u>Total</u>: $ <?php echo number_format($total*1.07); ?></h3>
		<br>
		<h2>Thank you for purchasing our insurance!</h2>
		<h2>
			<a id="continue" href="region.php">Click here to continue shopping</a>
		</h2>
	</div>
</center>

<?php require('footer.php'); ?>
 	
<?php
unset($_SESSION['prodCart']);

?>