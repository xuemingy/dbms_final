<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
        <title>使用 PDO 新增紀錄</title>
    </head>
<body>
    <h1>PDO：新增紀錄</h1>

    <?php
    $action = isset($_POST['action']) ? $_POST['action'] : "";

    if($action=='create'){
        //include database connection
        include 'db_connect.php';

        try{

            //write query
            $query = "INSERT INTO employee SET e_id = ?, h_id = ?, e_name = ?, e_email  = ?, job_title = ?, salary = ?, a_id = ?";

            //prepare query for excecution
            $stmt = $con->prepare($query);

            //bind the parameters
            //this is the first question mark
            $stmt->bindParam(1, $_POST['e_id']);

            //this is the second question mark
            $stmt->bindParam(2, $_POST['h_id']);

            //this is the third question mark
            $stmt->bindParam(3, $_POST['e_name']);

            //this is the fourth question mark
            $stmt->bindParam(4, $_POST['e_email']);

            $stmt->bindParam(5, $_POST['job_title']);

            $stmt->bindParam(6, $_POST['salary']);

            $stmt->bindParam(7, $_POST['a_id']);

            // Execute the query
            if($stmt->execute()){

                echo "Record was saved.";
            }else{
                //不中斷程序 使用 echo 輸出
                //die('Unable to save record.');
                echo "Unable to save record.";
            }

        }catch(PDOException $exception){ //to handle error
            echo "Error: " . $exception->getMessage();
        }
    }

    ?>

    <!--we have our html form here where user information will be entered-->
    <form action='#' method='post' border='0'>
        <table>
            <tr>
                <td>e_id</td>
                <td><input type='text' name='e_id' /></td>
            </tr>
            <tr>
                <td>h_id</td>
                <td><input type='text' name='h_id' /></td>
            </tr>
            <tr>
                <td>e_name</td>
                <td><input type='text' name='e_name' /></td>
            </tr>
            <tr>
                <td>e_email</td>
                <td><input type='password' name='e_email' /></td>
            </tr>
            <tr>
                <td>job_title</td>
                <td><input type='text' name='job_title' /></td>
            </tr>
            <tr>
                <td>salary</td>
                <td><input type='text' name='salary' /></td>
            </tr>
            <tr>
                <td>a_id</td>
                <td><input type='text' name='a_id' /></td>
            </tr>
                <td></td>
                <td>
                    <input type='hidden' name='action' value='create' />
                    <input type='submit' value='Save' />

                    <a href='admin.php'>Back to admin</a>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
