<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>admin</title>
    <link href="https://cdn.bootcss.com/twitter-bootstrap/4.1.3/css/bootstrap-grid.css" rel="stylesheet">
</head>

<body>
    <form method="post" id="login-form">
        <div>
            <input style="width: 25%; height: 5%; border-radius: 5px;" type="text" class="form-control" placeholder="Enter your employee id"
                name="username" required />
        </div>

        <div>
            <input style="width: 25%; height: 5%; border-radius: 5px;" type="password" class="form-control" placeholder="Enter hotel id"
                name="password" required />
        </div>

        <div>
            <button style="width: 25%; height: 3%" type="submit" class="btn btn-default" name="btn-login" id="btn-login">
                <span></span> &nbsp; Log In
            </button>
        </div>
    </form>
    
</body>
<?php
    session_start();
    require_once 'db_connect.php';

    //If user click button login. Get username and password.
    if (isset($_POST['btn-login'])) {
        $userName = strip_tags($_POST['username']);
        $userPass = strip_tags($_POST['password']);
    
        $userName = $DBcon->real_escape_string($userName);
        $userPass = $DBcon->real_escape_string($userPass);
 
        //If user click button login. Get username and password.
        if (isset($_POST['btn-login'])) {
            $userName = strip_tags($_POST['username']);
            $userPass = strip_tags($_POST['password']);
    
            $userName = $DBcon->real_escape_string($userName);
            $userPass = $DBcon->real_escape_string($userPass);
            

    
            //Getting user information by using username. Then compare password.
            $query = $DBcon->query("SELECT e_id, h_id, e_name FROM employee WHERE e_id='$userName'");
            $row=$query->fetch_array();
    
            //If user exists. $count must = 1.
            $count = $query->num_rows;
            
           

            //Check if password is correct or not. If match, show success page.
            if ($userPass == $row['h_id'] && $count==1) {

                $_SESSION['userSession'] = $row['e_id'];
                echo $row['e_id'];
                header("Location: admin.php");
            }
    
    
            //If password not match, show error.
            else {
                $msg = "<div>
             <h3 style=\"color: red\"> &nbsp; Invalid Username or Password !</h3>
             </div>";
            }
            $DBcon->close();
        }
    }
       ?>
</html>