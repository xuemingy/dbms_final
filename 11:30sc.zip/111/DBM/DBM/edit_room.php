<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
    <title>PDO 更新紀錄</title>
</head>
<body>

<h1>PDO: 更新紀錄</h1>

<?php
//include database connection
include 'db_connect.php';

$action = isset( $_POST['action'] ) ? $_POST['action'] : "";
if($action == "update"){
    try{

        //write query
        //in this case, it seemed like we have so many fields to pass and 
        //its kinda better if we'll label them and not use question marks
        //like what we used here
        $query = "update room 
                    set r_id = :r_id, r_kind = :r_kind, h_id = h_id, state = :state
                    where r_id = :r_id";

        //prepare query for excecution
        $stmt = $con->prepare($query);

        //bind the parameters
        $stmt->bindParam(':r_id', $_POST['r_id']);
        $stmt->bindParam(':r_kind', $_POST['r_kind']);
        $stmt->bindParam(':h_id', $_POST['h_id']);
        $stmt->bindParam(':state', $_POST['state']);
        

        // Execute the query
        if($stmt->execute()){
            echo "Record was updated.";
        }else{
            //不中斷程序 使用 echo 輸出
            //die('Unable to update record.');
            echo 'Unable to update record.';
        }

    }catch(PDOException $exception){ //to handle error
        echo "Error: " . $exception->getMessage();
    }
}

try {

    //prepare query
    $query = "select r_id, r_kind,h_id, state from room where r_id = ? limit 0,1";
    $stmt = $con->prepare( $query );

    //this is the first question mark
    $stmt->bindParam(1, $_REQUEST['r_id']);

    //execute our query
    $stmt->execute();

    //store retrieved row to a variable
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    //values to fill up our form
    $r_id = $row['r_id'];
    $r_kind = $row['r_kind'];
    $h_id = $row['h_id'];
    $state = $row['state'];
   

}catch(PDOException $exception){ //to handle error
    echo "Error: " . $exception->getMessage();
}


?>
<!--we have our html form here where new user information will be entered-->
<form action='#' method='post' border='0'>
    <table>
        <tr>
            <td>r_id</td>
            <td><input type='text' name='r_id' value='<?php echo $r_id;  ?>' /></td>
        </tr>
        <tr>
            <td>r_kind</td>
            <td><input type='text' name='r_kind' value='<?php echo $r_kind;  ?>' /></td>
        </tr>
        <tr>
            <td>h_id</td>
            <td><input type='text' name='h_id'  value='<?php echo $h_id;  ?>' /></td>
        </tr>
        <tr>
            <td>state</td>
            <td><input type='text' name='state'  value='<?php echo $state;  ?>' /></td>
        </tr>

        
            <td></td>
            <td>
                <!-- so that we could identify what record is to be updated -->
                <input type='hidden' name='r_id' value='<?php echo $r_id ?>' />

                <!-- we will set the action to edit -->
                <input type='hidden' name='action' value='update' />
                <input type='submit' value='Edit' />

                <a href='room_manage.php'>room_manage</a>
            </td>
        </tr>
    </table>
</form>

</body>
</html>