<?php
/**
 * Created by IntelliJ IDEA.
 * User: Hsu
 * Date: 2014/9/25
 * Time: 下午 03:54
 */

$host = "localhost";
$port = "3306";
$db_name = "final";
$username = "DBproject";
$password = "123456";

try {
    $con = new PDO("mysql:host={$host};port={$port};dbname={$db_name}", $username, $password);
    //設定錯誤模式，以啟用顯示系統錯誤，若不設定，則顯示自訂的輸出訊息
    $con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    // 或者是使用
    //$con = new PDO("mysql:host={$host};port={$port};dbname={$db_name}", $username, $password, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
}

// to handle connection error
catch(PDOException $exception){
    echo "Connection error: " . $exception->getMessage();
}

//Connect to database.
$DBcon = new mysqli("localhost", "DBproject", "123456", "hotelmanagement");

if ($DBcon->connect_errno) {
    die ("Error: ". $DBcon->connect_error);
}