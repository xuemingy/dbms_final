<?php
//include database connection
include 'db_connect.php';

try {

    // delete query
    $query = "DELETE FROM employee WHERE e_id = ?";
    $stmt = $con->prepare($query);
    $stmt->bindParam(1, $_GET['e_id']);

    if($result = $stmt->execute()){
        // redirect to index page
        header('Location: admin.php?action=deleted');
    }else{
        //不中斷程序 使用 echo 輸出
        //die('Unable to delete record.');
        echo 'Unable to delete record.';
    }
}

// to handle error
catch(PDOException $exception){
    echo "Error: " . $exception->getMessage();
}