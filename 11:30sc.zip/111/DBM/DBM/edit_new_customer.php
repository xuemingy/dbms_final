<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
    <title>PDO 更新紀錄</title>
</head>
<body>

<h1>PDO: 更新紀錄</h1>

<?php
//include database connection
include 'db_connect.php';

$action = isset($_POST['action']) ? $_POST['action'] : "";
if ($action == "update") {
    try {

        //write query
        //in this case, it seemed like we have so many fields to pass and
        //its kinda better if we'll label them and not use question marks
        //like what we used here
        $query = "update address 
                    set  a_id = :a_id, country = :country, city = :city, street = :street, zip = :zip
                    where a_id = :a_id";

        $query2 = "update customer 
                    set  c_id = :c_id, c_name = :c_name, a_id = :a_id, gender = :gender, age = :age, phone = :phone, c_email= :c_email, password = :password                   
                    where c_id =:c_id and a_id = :a_id";


        //prepare query for excecution
        $stmt = $con->prepare($query);

        $stmt2 = $con->prepare($query2);

        //bind the parameters
        $stmt->bindParam(':a_id', $_POST['a_id']);
        $stmt->bindParam(':country', $_POST['country']);
        $stmt->bindParam(':city', $_POST['city']);
        $stmt->bindParam(':street', $_POST['street']);
        $stmt->bindParam(':zip', $_POST['zip']);


        $stmt2->bindParam(':c_id', $_POST['c_id']);
        $stmt2->bindParam(':c_name', $_POST['c_name']);
        $stmt2->bindParam(':a_id', $_POST['a_id']);
        $stmt2->bindParam(':gender', $_POST['gender']);
        $stmt2->bindParam(':age', $_POST['age']);
        $stmt2->bindParam(':phone', $_POST['phone']);
        $stmt2->bindParam(':c_email', $_POST['c_email']);
        $stmt2->bindParam(':password', $_POST['password']);
        


        

        // Execute the query
        if ($stmt->execute()) {
            echo "Record was updated.";
        } else {
            //不中斷程序 使用 echo 輸出
            //die('Unable to update record.');
            echo 'Unable to update record.';
        }

        if ($stmt2->execute()) {
            echo "Record was updated.";
        } else {
            //不中斷程序 使用 echo 輸出
            //die('Unable to update record.');
            echo 'Unable to update record.';
        }
    } catch (PDOException $exception) { //to handle error
        echo "Error: " . $exception->getMessage();
    }
}

try {

    //prepare query
    $query = "select a_id, country,city, street, zip from address where a_id = ? limit 0,1";
    $stmt = $con->prepare($query);

    $query2 = "select c_id, c_name, gender, age, phone, c_email, password from customer where c_id = ? limit 0,1";
    $stmt2 = $con->prepare($query2);


    //this is the first question mark
    $stmt->bindParam(1, $_REQUEST['a_id']);

    //execute our query
    $stmt->execute();

//////////////////////////////////////////////////////////////////////////////////////////////
     //this is the first question mark
     $stmt2->bindParam(1, $_REQUEST['c_id']);

     //execute our query
     $stmt2->execute();

    //store retrieved row to a variable
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    //values to fill up our form
    $a_id = $row['a_id'];
    $country = $row['country'];
    $city = $row['city'];
    $street = $row['street'];
    $zip = $row['zip'];

    //////////////////////////////////////////////////////////////////////////////////////////

    //store retrieved row to a variable
    $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);

    //values to fill up our form
    $c_id = $row2['c_id'];
    $c_name = $row2['c_name'];
    $gender = $row2['gender'];
    $age = $row2['age'];
    $phone = $row2['phone'];
    $c_email = $row2['c_email'];
    $password = $row2['password'];


} catch (PDOException $exception) { //to handle error
    echo "Error: " . $exception->getMessage();
}


?>
<!--we have our html form here where new user information will be entered-->
<form action='#' method='post' border='0'>
    <table>

    <!-- <tr>
            <td>a_id</td>
            <td><input type='text' name='a_id' value='<?php echo $a_id;  ?>' /></td>
        </tr> -->
        
        <tr>
            <td>country</td>
            <td><input type='text' name='country' value='<?php echo $country;  ?>' /></td>
        </tr>
        <tr>
            <td>city</td>
            <td><input type='text' name='city'  value='<?php echo $city;  ?>' /></td>
        </tr>
        <tr>
            <td>street</td>
            <td><input type='text' name='street'  value='<?php echo $street;  ?>' /></td>
        </tr>
        <tr>
            <td>zip</td>
            <td><input type='text' name='zip'  value='<?php echo $zip;  ?>' /></td>
        </tr>

        <!-- <tr>
            <td>c_id</td>
            <td><input type='text' name='c_id'  value='<?php echo $c_id;  ?>' /></td>
        </tr><tr> -->
            <td>c_name</td>
            <td><input type='text' name='c_name'  value='<?php echo $c_name;  ?>' /></td>
        </tr><tr>
            <td>gender</td>
            <td><input type='text' name='gender'  value='<?php echo $gender;  ?>' /></td>
        </tr><tr>
            <td>age</td>
            <td><input type='text' name='age'  value='<?php echo $age;  ?>' /></td>
        </tr><tr>
            <td>phone</td>
            <td><input type='text' name='phone'  value='<?php echo $phone;  ?>' /></td>
        </tr><tr>
            <td>c_email</td>
            <td><input type='text' name='c_email'  value='<?php echo $c_email;  ?>' /></td>
        </tr><tr>
            <td>password</td>
            <td><input type='text' name='password'  value='<?php echo $password;  ?>' /></td>
        </tr>

        
            <td></td>
            <td>
                <!-- so that we could identify what record is to be updated -->
                <input type='hidden' name='a_id' value='<?php echo $a_id ?>' />

                <input type='hidden' name='c_id' value='<?php echo $c_id ?>' />

                <!-- we will set the action to edit -->
                <input type='hidden' name='action' value='update' />
                <input type='submit' value='Edit' />

                <a href='customer_manage.php'>room_manage</a>
            </td>
        </tr>
    </table>
</form>

</body>
</html>