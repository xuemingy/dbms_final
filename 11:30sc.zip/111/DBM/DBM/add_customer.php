<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
        <title>new customer</title>
    </head>
<body>
    <h1>new customer</h1>

    <?php
    $action = isset($_POST['action']) ? $_POST['action'] : "";

    if ($action=='create') {
        //include database connection
        include 'db_connect.php';

        try {


            $query = "INSERT INTO address SET country = ?, city = ?, street = ?, zip  = ?";
            $query1 =  "select a_id from address where country =? and city = ? and street = ? and zip =?";

            $query2 = "INSERT INTO customer SET c_name = ?, a_id = ?, gender = ?, age  = ?, phone = ?, c_email = ?, password = ?";
         
            $a_id_temp;
            
            //   $DBcon->query("ALTER TABLE customer AUTO_INCREMENT=1");
            //prepare query for excecution
            $stmt = $con->prepare($query);
            $stmt1 = $con->prepare($query1);
            $stmt2 = $con->prepare($query2);

            //bind the parameters
            //this is the first question mark
            $stmt->bindParam(1, $_POST['country']);

            //this is the second question mark
            $stmt->bindParam(2, $_POST['city']);

            //this is the third question mark
            $stmt->bindParam(3, $_POST['street']);

            //this is the fourth question mark
            $stmt->bindParam(4, $_POST['zip']);
             // Execute the query
             if ($stmt->execute()) {
                echo "Record was saved.";
            } else {
                //不中斷程序 使用 echo 輸出
                //die('Unable to save record.');
                echo "Unable to save record.";
            }
            $stmt1->bindParam(1, $_POST['country']);

            //this is the second question mark
            $stmt1->bindParam(2, $_POST['city']);

            //this is the third question mark
            $stmt1->bindParam(3, $_POST['street']);

            //this is the fourth question mark
            $stmt1->bindParam(4, $_POST['zip']);
            if ($stmt1->execute()) {
                $num = $stmt1->rowCount();

                if ($num>0) { //check if more than 0 record found
                    while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {
                        //extract row
                        //this will make $row['firstname'] to
                        //just $firstname only
                        //http://tw1.php.net/manual/zh/function.extract.php
                        extract($row);

                        //creating new table row per record
                    
                        $a_id_temp = $a_id;
                        
             
                    }

                }
                // echo $a_id_temp;

            } else {
                echo "Unable to save record.";
            }

            $stmt2->bindParam(1, $_POST['c_name']);
            $stmt2->bindParam(2, $a_id_temp);
            $stmt2->bindParam(3, $_POST['gender']);
            $stmt2->bindParam(4, $_POST['age']);
            $stmt2->bindParam(5, $_POST['phone']);
            $stmt2->bindParam(6, $_POST['c_email']);
            $stmt2->bindParam(7, $_POST['password']);
            

           
           

            if ($stmt2->execute()) {
                echo "Record was saved.";
            } else {
                //不中斷程序 使用 echo 輸出
                //die('Unable to save record.');
                echo "Unable to save record.";
            }

        } catch (PDOException $exception) { //to handle error
            echo "Error: " . $exception->getMessage();
        }
            

    }

    ?>

    <!--we have our html form here where user information will be entered-->
    <form action='#' method='post' border='0'>
        <table>
            <tr>
                <td>c_name</td>
                <td><input type='text' name='c_name' /></td>
            </tr>
           
            <tr>
                <td>gender</td>
                <td><input type='text' name='gender' /></td>
            </tr>
            <tr>
                <td>age</td>
                <td><input type='text' name='age' /></td>
            </tr>
            <tr>
                <td>phone</td>
                <td><input type='text' name='phone' /></td>
            </tr>
            <tr>
                <td>c_email</td>
                <td><input type='text' name='c_email' /></td>
            </tr>
            
            <tr>
                <td>password</td>
                <td><input type='text' name='password' /></td>
            </tr>
            <tr>
                <td>country</td>
                <td><input type='text' name='country' /></td>
            </tr>
            <tr>
                <td>city</td>
                <td><input type='text' name='city' /></td>
            </tr>
            <tr>
                <td>street</td>
                <td><input type='text' name='street' /></td>
            </tr>
            <tr>
                <td>zip</td>
                <td><input type='text' name='zip' /></td>
            </tr>

                <td></td>
                <td>
                    <input type='hidden' name='action' value='create' />
                    <input type='submit' value='Save' />

                    <a href='customer_manage.php'>Back to manage customer</a>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
