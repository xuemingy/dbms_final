<?php
//include database connection
include 'db_connect.php';

try {

    // delete query
    $query = "DELETE FROM address WHERE a_id = ?";
    $stmt = $con->prepare($query);
    $stmt->bindParam(1, $_GET['a_id']);

    ///////////////////////////////////////////////////
    $query2 = "DELETE FROM customer WHERE a_id = ? and c_id = ?";
    $stmt2 = $con->prepare($query2);
    $stmt2->bindParam(1, $_GET['a_id']);

    if($result = $stmt->execute()){
        // redirect to index page
        header('Location: customer_manage.php?action=deleted');
    }else{
        //不中斷程序 使用 echo 輸出
        //die('Unable to delete record.');
        echo 'Unable to delete record.';
    }

    if($result = $stmt2->execute()){
        // redirect to index page
        header('Location: customer_manage.php?action=deleted');
    }else{
        //不中斷程序 使用 echo 輸出
        //die('Unable to delete record.');
        echo 'Unable to delete record.';
    }
}

// to handle error
catch(PDOException $exception){
    echo "Error: " . $exception->getMessage();
}