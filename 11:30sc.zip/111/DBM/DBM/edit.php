<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
    <title>PDO 更新紀錄</title>
</head>
<body>

<h1>PDO: 更新紀錄</h1>

<?php
//include database connection
include 'db_connect.php';

$action = isset( $_POST['action'] ) ? $_POST['action'] : "";
if($action == "update"){
    try{

        //write query
        //in this case, it seemed like we have so many fields to pass and 
        //its kinda better if we'll label them and not use question marks
        //like what we used here
        $query = "update employee 
                    set e_id = :e_id, e_name = :e_name, a_id = a_id, e_email = :e_email, job_title  = :job_title, h_id = :h_id, salary = :salary
                    where e_id = :e_id";

        //prepare query for excecution
        $stmt = $con->prepare($query);

        //bind the parameters
        $stmt->bindParam(':e_id', $_POST['e_id']);
        $stmt->bindParam(':e_name', $_POST['e_name']);
        $stmt->bindParam(':e_email', $_POST['e_email']);
        $stmt->bindParam(':job_title', $_POST['job_title']);
        $stmt->bindParam(':h_id', $_POST['h_id']);
        $stmt->bindParam(':salary', $_POST['salary']);
    
        // Execute the query
        if($stmt->execute()){
            echo "Record was updated.";
        }else{
            //不中斷程序 使用 echo 輸出
            //die('Unable to update record.');
            echo 'Unable to update record.';
        }

    }catch(PDOException $exception){ //to handle error
        echo "Error: " . $exception->getMessage();
    }
}

try {

    //prepare query
    $query = "select e_id, e_name,a_id, e_email, job_title, h_id, salary from employee where e_id = ? limit 0,1";
    $stmt = $con->prepare( $query );

    //this is the first question mark
    $stmt->bindParam(1, $_REQUEST['id']);

    //execute our query
    $stmt->execute();

    //store retrieved row to a variable
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    //values to fill up our form
    $e_id = $row['e_id'];
    $e_name = $row['e_name'];
    $a_id = $row['a_id'];
    $e_email = $row['e_email'];
    $job_title = $row['job_title'];
    $h_id = $row['h_id'];
    $salary = $row['salary'];

}catch(PDOException $exception){ //to handle error
    echo "Error: " . $exception->getMessage();
}


?>
<!--we have our html form here where new user information will be entered-->
<form action='#' method='post' border='0'>
    <table>
        <tr>
            <td>e_id</td>
            <td><input type='text' name='e_id' value='<?php echo $e_id;  ?>' /></td>
        </tr>
        <tr>
            <td>h_id</td>
            <td><input type='text' name='h_id' value='<?php echo $h_id;  ?>' /></td>
        </tr>
        <tr>
            <td>e_name</td>
            <td><input type='text' name='e_name'  value='<?php echo $e_name;  ?>' /></td>
        </tr>
        <tr>
            <td>e_email</td>
            <td><input type='text' name='e_email'  value='<?php echo $e_email;  ?>' /></td>
        </tr>

        <tr>
            <td>job_title</td>
            <td><input type='text' name='job_title'  value='<?php echo $job_title;  ?>' /></td>
        </tr>

        <tr>
            <td>h_id</td>
            <td><input type='text' name='h_id'  value='<?php echo $h_id;  ?>' /></td>
        </tr>

        <tr>
            <td>salary</td>
            <td><input type='text' name='salary'  value='<?php echo $salary;  ?>' /></td>
        </tr>
            <td></td>
            <td>
                <!-- so that we could identify what record is to be updated -->
                <input type='hidden' name='e_id' value='<?php echo $e_id ?>' />

                <!-- we will set the action to edit -->
                <input type='hidden' name='action' value='update' />
                <input type='submit' value='Edit' />

                <a href='admin.php'>Back to admin</a>
            </td>
        </tr>
    </table>
</form>

</body>
</html>