<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
        <title>使用 PDO 新增紀錄</title>
    </head>
<body>
    <h1>PDO：新增紀錄</h1>

    <?php
    $action = isset($_POST['action']) ? $_POST['action'] : "";

    if($action=='create'){
        //include database connection
        include 'db_connect.php';

        try{

            //write query
            $query = "INSERT INTO room SET r_id = ?, r_kind = ?, h_id = ?, state  = ?";

            //prepare query for excecution
            $stmt = $con->prepare($query);

            //bind the parameters
            //this is the first question mark
            $stmt->bindParam(1, $_POST['r_id']);

            //this is the second question mark
            $stmt->bindParam(2, $_POST['r_kind']);

            //this is the third question mark
            $stmt->bindParam(3, $_POST['h_id']);

            //this is the fourth question mark
            $stmt->bindParam(4, $_POST['state']);


            // Execute the query
            if($stmt->execute()){

                echo "Record was saved.";
            }else{
                //不中斷程序 使用 echo 輸出
                //die('Unable to save record.');
                echo "Unable to save record.";
            }

        }catch(PDOException $exception){ //to handle error
            echo "Error: " . $exception->getMessage();
        }
    }

    ?>

    <!--we have our html form here where user information will be entered-->
    <form action='#' method='post' border='0'>
        <table>
            <tr>
                <td>r_id</td>
                <td><input type='text' name='r_id' /></td>
            </tr>
            <tr>
                <td>r_kind</td>
                <td><input type='text' name='r_kind' /></td>
            </tr>
            <tr>
                <td>h_id</td>
                <td><input type='text' name='h_id' /></td>
            </tr>
            <tr>
                <td>state</td>
                <td><input type='text' name='state' /></td>
            </tr>
           
                <td></td>
                <td>
                    <input type='hidden' name='action' value='create' />
                    <input type='submit' value='Save' />

                    <a href='room_manage.php'>Back to room_manage</a>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
