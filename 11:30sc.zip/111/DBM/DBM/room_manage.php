<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
    <title>manage room</title>
    <style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 200px;
    background-color: #f1f1f1;
}

li a {
    display: block;
    color: #000;
    padding: 8px 16px;
    text-decoration: none;
}

li a.active {
    background-color: #4CAF50;
    color: white;
}

li a:hover:not(.active) {
    background-color: #555;
    color: white;
}
</style>
</head>
<body>

<h1>Room Management</h1>

<ul>
  <li><a  href="admin.php">Employee Managements</a></li>
  <li><a href="manage_customer.php">Customer Management</a></li>
  <li><a href="order_manage.php">Order Managementr</a></li>
  <li><a class="active" href="room_manage.php">Room Management</a></li>
</ul>

<?php
//include database connection
include 'db_connect.php';

$action = isset($_GET['action']) ? $_GET['action'] : "";

// if it was redirected from delete.php
if ($action=='deleted') {
    echo "<div>Record was deleted.</div>";
}

//select all data
$query = "SELECT r_id, r_kind, h_id, state FROM room";

$stmt = $con->prepare($query);
$stmt->execute();

//this is how to get number of rows returned
$num = $stmt->rowCount();

echo "<a href='add_room.php'>Create New Record</a>";

if ($num>0) { //check if more than 0 record found

    echo "<table border='1'>";//start table

    //creating our table heading
    echo "<tr>";
    echo "<th>r_id</th>";
    echo "<th>r_kind</th>";
    echo "<th>h_id</th>";
    echo "<th>state</th>";
    echo "<th>action</th>";
    echo "</tr>";


    

    //retrieve our table contents
    //fetch() is faster than fetchAll()
    //http://stackoverflow.com/questions/2770630/pdofetchall-vs-pdofetch-in-a-loop
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        //extract row
        //this will make $row['firstname'] to
        //just $firstname only
        //http://tw1.php.net/manual/zh/function.extract.php
        extract($row);

        //creating new table row per record
        echo "<tr>";
        echo "<td>{$r_id}</td>";
        echo "<td>{$r_kind}</td>";
        echo "<td>{$h_id}</td>";
        echo "<td>{$state}</td>";
        
        echo "<td>";


        //we will use this links on next part of this post
        echo "<a href='edit_room.php?r_id={$r_id}'>Edit</a>";
        echo " / ";
        //we will use this links on next part of this post
        echo "<a href='#' onclick='delete_user( {$r_id} );'>Delete</a>";
        echo "</td>";
        echo "</tr>";
    }

    //end table
    echo "</table>";
}

//if no records found
else {
    echo "No records found.";
}

?>

<script type='text/javascript'>
    function delete_user( r_id ){

        var answer = confirm('你確定嗎?');
        if ( answer ){

            //if user clicked ok, pass the id to delete.php and execute the delete query
            window.location = 'delete_room.php?r_id=' + r_id;
        }
    }
</script>

</body>
</html>