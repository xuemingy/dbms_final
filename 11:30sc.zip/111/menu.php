<?php
//Hotel: first->region, second->hotel, third->room+service
?>
<!-- Edit by Sc-->
<!-- 页面最上方菜单栏-->
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<!DOCTYPE html>
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
		body {font-family: "Lato", sans-serif}
		.mySlides {display: none}
	</style>

</head>
<body>
	<div class="w3-top">
		<div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
			<a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
			<a href="index.php" class="w3-bar-item w3-button w3-padding-large"><b>YST INSURANCE</b></a>
			<a href="products.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">INSURANCE</a>
			<a href="yourcart.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">CART</a>
			<a href="signin.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">SIGN IN</a>
			<a href="contact.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">CONTACT</a>
			<a href="./DBM/DBM/admin_login.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small w3-grey w3-right">ADMIN</a>
		</div>
	</div>
</body>


